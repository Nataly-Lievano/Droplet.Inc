
import scala.io.StdIn.readLine

object calculadora {

   def main(args:Array[String]):Unit= {
   }
   def multiplicacion(a:Int,b:Int, c:Int = 1, d:Int = 1, e:Int = 1, g:Int = 1):Int = {
     a*b*c*d*e*g
   }
   def suma(a:Int, b:Int, c:Int = 1, d:Int = 1, e:Int = 1, g:Int = 1 ): Int  = {
     a+b+c+d+e+g
   }
   def porcentaje(a:Int):Int = {
     a/100
   }
   def dividir(a:Int=1, b:Int=1):Int={
     a/b
   }



    println("Ingresa el número de trabajadores")
    private val trabajadores: Int = readLine().toInt
    println("Ingresa el valor de la hora")
    private val valorHora: Int = readLine().toInt
    println("Ingresa el número de horas a trabajar")
    private val horas: Int = readLine().toInt
    val costoTrabajador: Int = multiplicacion(trabajadores, valorHora, horas)

    println("Ingresa el número de horas de holgura que quieres dejar")
    var holgura: Int = readLine().toInt
    holgura = multiplicacion(trabajadores, valorHora, holgura)

    println("Ingresa el costo del equipamiento técnico")
    var equipo: Int = readLine().toInt
    println("Ingresa el costo del plan de internet mensual de la empresa")
    var internet: Int = readLine().toInt

    def costoInternet(a:Int):Int = {
       dividir(dividir(a, multiplicacion(30,24)), horas)
    }
   internet = costoInternet(internet)

  println("Ingresa el costo de las oficinas")
  val oficinas: Int = readLine().toInt
   equipo = suma(equipo,internet,oficinas)

    println("¿Su contador cobra por porcentaje?  Ingrese true para si y false para no")
  var cobroContador: Boolean = readLine().toBoolean
  var valorContador: Int = 0
  val cap: Int = suma(costoTrabajador, equipo, holgura)
  if(cobroContador == true){
    println("Ingresa el porcentaje que cobra el contador (sólo el número sin símbolo porcentaje)")
     valorContador = readLine().toInt
        valorContador = multiplicacion(cap,porcentaje(valorContador))
  }else{
    println("Ingresa el sueldo del contador ")
     valorContador = readLine().toInt
  }

    val capitalizacion: Int = porcentaje(costoTrabajador)
    println("Ingresa el valor del impuesto de Cámara y comercio")
    val camaraComercio: Int = readLine().toInt

    println("Ingresa el valor del impuesto de Industria y comercio")
    val induComercio: Int = readLine().toInt

    val iva: Int = multiplicacion(suma(costoTrabajador,holgura,equipo,valorContador),porcentaje(19))
    val retFuente: Int = multiplicacion(suma(costoTrabajador, holgura, equipo, valorContador), porcentaje(11))
    val reteIca: Int = multiplicacion(suma(costoTrabajador, holgura, equipo, valorContador), porcentaje(1))


    val costoTotal: Int = suma(suma(costoTrabajador,valorContador,capitalizacion,camaraComercio,induComercio),suma(equipo,iva,retFuente,reteIca,holgura))

   println("El costo total del proyecto será de: '$'" + costoTotal)


}



